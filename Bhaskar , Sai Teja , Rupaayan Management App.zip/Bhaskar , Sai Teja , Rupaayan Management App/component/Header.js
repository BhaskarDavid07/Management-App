import React from 'react';
import { Link } from 'react-router-dom'

export default function Header() {
  return (
    <div className='mt-5 shadow-md pb-6'>
        <nav className='flex'>
            <Link to='/'><h1 className=' ml-3 pl-5 text-3xl font-bold mt-2 cursor-pointer mr-[760px]'>Management App 🤝🏻</h1></Link>
              <Link to="/register">
              <button className="w-full text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none  focus:ring-primary-300 font-medium rounded-lg text-md px-5 py-2.5 my-3 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">
              Register
              </button>
              </Link>
        </nav>
    </div>
  )
}
