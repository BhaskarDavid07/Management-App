import { Route, Routes } from "react-router-dom";
import LoginPage from "./pages/Loginpage";
import DashboardPage from "../src/pages/Dashboardpage";
import RegisterPage from "./pages/RegisterPage";
import Header from "./component/Header";
import Projectpage from "./pages/Projectpage";
import ProtectedRoute from "./component/ProtectedRoute";

function App() {
  return (
    <>
      <Header/>
      <div className='bg-gradient-to-br from-gray-50 to-slate-400'>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route
          path="/dashboard/:id"
          element={
              <ProtectedRoute>
              <DashboardPage />
              </ProtectedRoute>
          }
        ></Route>
        <Route path="/dashboard/:id/project/:projectId" element={<Projectpage/>}/>
        <Route path ="/register" element={<RegisterPage/>}/>
      </Routes>
      </div>  
    </>
  );
}

export default App;