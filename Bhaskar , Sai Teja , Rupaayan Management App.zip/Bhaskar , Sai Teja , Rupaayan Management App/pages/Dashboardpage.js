import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProjects, addProject, updateProjectNameLocally, deleteProject,toggleEditState } from '../store/ProjectSlice';
import { useParams,Link } from 'react-router-dom';

const DashboardPage = () => {
  const {id,projectId}= useParams()
  const dispatch = useDispatch();
  const projects = useSelector((state) => state.projects.projects);
  const [newProjectData, setNewProjectData] = useState({ name: '', description: '' });
  const [usersData,setUsersData] = useState([]);

  useEffect(() => {
    dispatch(fetchProjects(id));
  }, [dispatch, id]);


  const handleAddProject = () => {
    dispatch(addProject({ id, ...newProjectData }));
    setNewProjectData({ name: '', description: '' });
  };

  const handleEditProject = (projectId) => {
    dispatch(toggleEditState({ projectId, isEditing: true }));
  };

  const handleProjectNameChange = (projectId, newName) => {
    dispatch(updateProjectNameLocally({ projectId, newName }));
  };
  

  const handleDeleteProject = (projectId) => {
    dispatch(deleteProject({ id, projectId }));
  };
  const getUserData= async()=>{
    try{
    const apiUrl =`https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}`
    const  rep =  await fetch(apiUrl);
    if(rep.ok){
      const value = await rep.json()
      setUsersData(value);
     
    }else {
      console.error('Error fetching projects:', rep.statusText);
    }
  } catch (error) {
    console.error('Error fetching projects:', error);
  }
  }
  console.log(usersData)
  useEffect(() => {
    getUserData();
  }, []);

  return (
    <section className="w-screen text-black">
      <div className='flex flex-col '>
      <div className=' py-3 px-2 mt-2 mx-2 rounded-lg gap-3'>   
      <div className='border-r-2 border-white '>
      <h2 className='text-2xl text-center font-semibold mt-3'>{usersData.name}</h2>
      <h3 className='text-xl text-center font-extralight mt-1'>{usersData.id}</h3>
      <h3 className='text-xl text-center font-extralight mt-1'>{usersData.email}</h3>
      </div>
      </div>
      
      <div className='py-3 px-2 rounded-lg ml-3 mt-5 '>
      <h2 className='text-2xl font-bold' >Projects</h2>
      <div className='border-2 border-black pl-4 rounded-md mt-2 mb-4'>
        <h3 className='my-2'>Add New Project</h3>
        <input
          className='h-8 p-3 rounded-md mb-5 text-black'
          type="text"
          value={newProjectData.name}
          onChange={(e) => setNewProjectData({ ...newProjectData, name: e.target.value })}
          placeholder="Project Name"
        /><br/>
        <textarea
          className='p-4 rounded-md mb-2 text-black w-[80%]'
          type="text"
          value={newProjectData.description}
          onChange={(e) => setNewProjectData({ ...newProjectData, description: e.target.value })}
          placeholder="Project Description"
        /><br/>
        <button className='bg-green-500 hover:bg-green-700 text-white rounded-md mb-3 p-2' onClick={handleAddProject}>Add Project</button>
      </div>
      <div>
        <h3 className='bg-green-600 w-full p-3 text-white text-center '>All Projects</h3>
        <div className='grid grid-cols-3 gap-4'>
        {projects.map((project) => (
  <div className='shadow-sm shadow-gray-50 bg-blue-600 text-white mt-4 p-3 rounded-md grid grid-cols-2 ' key={project.id}>
    {project.isEditing ? (
      <input
      className='text-black'
        type='text'
        value={project.name}
        onChange={(e) =>{
          handleProjectNameChange(project.id, e.target.value)}}
      />
    ) : (
      <Link to={`/dashboard/${id}/project/${project.id}`} className='block'>
      <h2 className='text-center font-semibold mt-3'>{project.name}</h2>
    </Link>
    )}
    <div className='flex ml-3 mt-3 gap-4'>
    <button
        className='rounded-md px-3'
        onClick={(event) => {
        event.stopPropagation();
        if (window.confirm("Are you sure you want to delete this project?")) {
         handleDeleteProject(project.id);
        }
    }}
    >
     Delete ❌
    </button>
      <button
        className='underline rounded-md px-3'
        onClick={(event) => {
          event.stopPropagation();
          handleEditProject(project.id)}}
      >
        {project.isEditing ? 'Save' : 'Edit'}
      </button>
    </div>
  </div>
))}


        </div>
       </div>
       </div>
       </div>
     </section>
  );
};

export default DashboardPage;