import React, { useEffect, useState } from 'react'
import {useParams } from 'react-router-dom'


export default function Projectpage() {
  const {id,projectId} = useParams()
  const apiUrl = `https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}/project/${projectId}`
  const [projectData, setProjectData] = useState([]);
  const [loading, setLoading] = useState(true);

  async function getProjectData() {
    const res = await fetch(apiUrl);
    const data = await res.json();
    setProjectData(data);
    setLoading(false);
    
  }
  console.log(projectData)
  useEffect(() => {
    getProjectData();
  }, [projectData]);

  if(loading) return "Fetching data...."


  return (
    <body className='text-black p-3 h-[600px] border-t-4'>
    <h1 className='text-2xl text-center font-bold'>Project Details</h1>   
    <div className=' mt-6 capitalize border-2 border-black rounded-md pb-5 shadow-md gap-20'>
      <h1 className='text-3xl py-10 text-center'>{projectData.name}</h1>
      <p className='px-5 '>{projectData.details}</p>
    </div>
    </body>
  );
}