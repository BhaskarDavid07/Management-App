// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import { BrowserRouter } from "react-router-dom";
// import './index.css';
// import App from './App'
// import UserStore from './context/UserStore';


// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//     <BrowserRouter>
//     <UserStore>
//      <App />
//      </UserStore>
//      </BrowserRouter>

// );

import ReactDOM from "react-dom/client";
import App from "./App";
import { BrowserRouter } from 'react-router-dom';
import { Provider } from "react-redux";
import { store } from "./store/store";
import "./index.css"
import UserStore from "./context/UserStore";

//Create A root entry point
const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <BrowserRouter>
  <UserStore>
  <Provider store={store}>
    <App/>
  </Provider>
  </UserStore>
  </BrowserRouter>
);


