import { configureStore } from "@reduxjs/toolkit";
import projectsSlice from "./ProjectSlice";

export const store = configureStore({
    reducer:{
        projects:projectsSlice
    }
})